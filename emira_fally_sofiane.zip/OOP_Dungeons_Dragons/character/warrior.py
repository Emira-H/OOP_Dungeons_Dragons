from character.character import Character
class Warrior(Character):

    def __init__(self):
        super().__init__(500, 50, 80, 10)
       
