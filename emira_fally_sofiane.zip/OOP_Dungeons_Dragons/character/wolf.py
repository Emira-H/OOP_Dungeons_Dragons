from character.character import Character
class Wolf(Character):

    def __init__(self):
        super().__init__(300, 30,15, 15)
        self.name="Wolf"
    


       
