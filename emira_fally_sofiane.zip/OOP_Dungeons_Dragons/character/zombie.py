from character.character import Character
class Zombie(Character):

    
    def __init__(self):
        super().__init__(600,15,15,5)
        self.name="Zombie"