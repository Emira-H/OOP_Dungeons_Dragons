from character.character import Character
class Archer(Character):

    def __init__(self):
        super().__init__(350,80,30,50)