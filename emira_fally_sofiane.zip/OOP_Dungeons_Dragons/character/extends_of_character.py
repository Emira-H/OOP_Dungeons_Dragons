from character.wizard import *
from character.wolf import *
from character.orc import *
from character.warrior import *
from character.zombie import *
from character.archer import *